package mainPackage;

/**
 * Esta interfaz contiene metodos propios de un juego de cartas.
 * Me parecio importante implementarla pues puede ser reutilizada para distintos
 * juegos de cartas en un futuro
 */
public interface IOperacionesCartas {
    public String tomarCarta();
    
    public void restaurarMazo();
}
