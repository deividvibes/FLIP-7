package mainPackage;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Esta clase se encarga de gestionar todos los eventos y acciones en el escenario: HowToPlay
 */
public class HowToPlayController{
    //Variables utiles para cambiar de escena
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    /**
    * 
     * Esta funcion nos ayuda a regresar a la escena: MenuPrincipal
     * @param click representa la accion de hacer click en un botón
     * @throws java.io.IOException por si intentamos cargar un archivo inexistente
    */
    public void pulsarBotonRegresar(ActionEvent click) throws IOException{
        //Creamos un nodo padre con el archivo FXML de la siguiente escena
        root = FXMLLoader.load(getClass().getResource("/MenuPrincipal.fxml"));
        //Obtenemos el escenario en que nos encontramos actualmente
        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();
        //Creamos una nueva escena en el nodo padre
        scene = new Scene(root);
        //La escena se establece en la ventana y la mostramos
        stage.setScene(scene);
        stage.show();
    }
}
