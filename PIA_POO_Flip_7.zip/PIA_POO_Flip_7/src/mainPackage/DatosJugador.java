package mainPackage;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;

/**
* Esta clase se encarga de manejar la informacion del jugador durante la escena SeleccionJugadores
*/
public class DatosJugador {
    //Durante la seleccion de jugador, cada jugador tiene:
    //Un panel que contiene todos los componentes
    private AnchorPane panel;
    //Una ChoiceBox para elegir entre Desactivado y Jugador(ChoiceBox y no CheckBox para incluir Bots en futuras versiones)
    private ChoiceBox<String> pStatus;
    //Boton Toggle para marcar que estas listo
    private ToggleButton listo;
    //Campo de texto para introducir nuestro Alias
    private TextField alias;
    //Campo para elegir el color del Jugador
    private ColorPicker color;
    //Etiqueta que muestra el alias del jugador en el color seleccionado al marcar LISTO
    private Label label;
    
    //Constructor de la clase
    public DatosJugador(AnchorPane panel, ChoiceBox<String> pStatus, ToggleButton listo, TextField alias, ColorPicker color, Label label){
        this.panel = panel;
        this.pStatus = pStatus;
        this.listo = listo;
        this.alias = alias;
        this.color = color;
        this.label = label;
    }
    //GETTERS Y SETTERS PARA TODOS LOS ATRIBUTOS
    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    public AnchorPane getPanel() {
        return panel;
    }

    public ChoiceBox<String> getpStatus() {
        return pStatus;
    }

    public ToggleButton getListo() {
        return listo;
    }

    public TextField getAlias() {
        return alias;
    }

    public ColorPicker getColor() {
        return color;
    }

    public void setPanel(AnchorPane panel) {
        this.panel = panel;
    }

    public void setpStatus(ChoiceBox<String> pStatus) {
        this.pStatus = pStatus;
    }

    public void setListo(ToggleButton listo) {
        this.listo = listo;
    }

    public void setAlias(TextField alias) {
        this.alias = alias;
    }

    public void setColor(ColorPicker color) {
        this.color = color;
    }

}
