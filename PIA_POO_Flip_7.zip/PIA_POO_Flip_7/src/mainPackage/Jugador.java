package mainPackage;

import java.util.ArrayList;
import java.util.HashSet;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;



/**
 * Esta clase se encarga de la informacion del jugador durante el escenario JuegoPrincipal
 */
public class Jugador {
    //Este arreglo contiene los espacios en pantalla donde se mostraran las cartas del jugador
    ArrayList<ImageView> mano_image = new ArrayList<>();
    //Esta Label muestra los puntos del jugador
    Label puntosL;
    //Muestra que accionse realizo, es la misma etiqueta para todos los jugadores
    Label Accion;
    //Un cuadrado que se muestra para indicar que el jugador se ha retirado
    Rectangle retiradoCuadro;

    //Representacion logica de la mano del jugador
    HashSet<String> mano = new HashSet<>();
    //Nombre elegido
    String alias;
    //puntos en mano, sujetos a perderlos si perdemos la ronda
    int puntos_mano;
    //puntos otorgados por cartas modificadores, se maneja por separado debido a que la carta X2
    //no debe afectar a los modificadores
    int modificadores;
    //Cantidad de cartas numericas; al llegar a 7 se obtiene una bonificacion y se acaba la ronda
    int flip;
    //Puntos no sujetos a ser perdidos
    int puntuacion;
    //booleano para saber si el jugador se retiró o no
    boolean retirado;
    
    //Constructor del Jugador
    public Jugador(String alias){
        this.alias = alias;
        this.puntos_mano = 0;
        this.puntuacion = 0;
        this.retirado = false;
        this.flip = 0;
    }
    /**
    * 
     * @param carta String que representa el tipo de carta obtenido
    */
    public void recibirCarta(String carta){
        //Al obtener una carta repetida
        if(mano.contains(carta)){
            //CASO DE CARTA ESPECIAL, NO IMPLEMENTADO********************************************************
            if(mano.contains("SC")){
                
                Accion.setText("El jugador ha sacado un " + carta + " y  ha gastado su segunda vida");

                mano.remove("SC");
            }
            //*******************************************************************************************
            else{
                //Perdemos los puntos y los modificadores
                this.puntos_mano = 0;
                this.modificadores = 0;
                //Mostramos que el jugador se ha retirado
                Accion.setText("El jugador ha sacado un " + carta + " y  ha perdido esta ronda");
                //Llamamos a la funcion retirarse()
                this.retirarse();
            }
            
        }
        //Si la carta no esta repetida
        else{
            //Añadimos la carta a la mano del jugador
            mano.add(carta);
            //Mostramos el mensaje en la etiqueta de accion
            Accion.setText("El jugador ha sacado un " + carta);
            //Si la carta es un modificador...
            if(carta.startsWith("+")){
                //Eliminamos el "+"
                carta = carta.replace("+", "");
                //Casteamos a int el numero de la carta
                int punto = Integer.parseInt(carta);
                //Sumamos la cantidad de puntos a modificadores
                modificadores += punto;
            }
            //Si la carta no es un modificador...
            else{
                //Casteamos a int el numero de la carta
               int punto = Integer.parseInt(carta);
               //sumamos una carta a la cuenta para flip 7
               this.flip++;
               //Sumamos la cantidad de puntos a puntos_mano
               puntos_mano += punto;  
            }
            //7 o mas cartas numericas?
            if(this.flip >= 7){
                //Mostramos el texto en pantalla
                Accion.setText("FLIP 7, El jugador tiene 7 cartas numericas y obtiene 15 puntos extra");
                //Sumamos 15 puntos de bonificacion por flip 7
                modificadores += 15;
            }
        }
    }
    //CARTA ESPECIAL NO IMPLEMENTADA************************************
    public void secondChance() {
        mano.add("SC");
        Accion.setText("EL JUGADOR HA OBTENIDO UN SECOND CHANCE");
    }
    //****************************************************************
    
    //Al obtener un X2 pasa por esta funcion que solo muestra en pantalla
    //y lo añade a la mano. No pasa por la funcion anterior puesto que no hay nada que sumar
    public void X2() {
        mano.add("X2");
        Accion.setText("EL JUGADOR HA OBTENIDO UN X2");
    }
    
    //Funcion para retirarse de la ronda
    public void retirarse(){
        //Se muestra un recuadro que indica que el jugador se retiro
        this.retiradoCuadro.setOpacity(0.20);
        //Se aplica el X2, si es que se tiene
        if(mano.contains("X2")){
            puntos_mano *= 2;
        }
        //Se Sumano los puntos de la mano y los modificadores
        puntuacion += puntos_mano;
        puntuacion += modificadores;
        //Se reinician los valores para la siguiente ronda
        puntos_mano = 0;
        modificadores = 0;
        flip = 0;
        //Para cada carta...
        for(String s:mano){
            //Existe en el mazo de descarte?
            if(Mazo.descarte.keySet().contains(s)){
                //Mediante una variable auxiliar, sumamos uno en la baraja de descarte
                int cant = Mazo.descarte.get(s);
                Mazo.descarte.replace(s, cant+1);
            }
            //No existe en el descarte? iniciamos en 1 el registro
            else{
                Mazo.descarte.put(s, 1);
            }
        }
        //Reiniciamos la mano
        mano.clear();
        //Estado: retirado
        retirado = true;
    }
    
    
}
