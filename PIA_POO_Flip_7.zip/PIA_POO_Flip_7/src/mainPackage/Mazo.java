package mainPackage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Label;

/**
 * Esta clase se encarga de gestionar el mazo
 * Sacar cartas y restaurarlo cuando se acabe
 * 
 */
public class Mazo implements IOperacionesCartas{
    
    //Esta estructura representa nuestro deck, la String es el tipo de carta y
    //el Integer es el numero de cartas de ese tipo que quedan
    HashMap<String, Integer> deck = new HashMap<>();
    //Etiqueta que muestra en pantalla las cartas restantes en el deck
    Label restantes;
    //El numero total de cartas en un inicio
    int total_cartas;
    
    //cuando se agote el mazo, esta variable nos ayudara a inicializarlo.
    static HashMap<String, Integer> descarte = new HashMap<>();
    
    //Constructor de Mazo
    public Mazo(){
        deck.put("0", 1);
        deck.put("1", 1);
        deck.put("2", 2);
        deck.put("3", 3);
        deck.put("4", 4);
        deck.put("5", 5);
        deck.put("6", 6);
        deck.put("7", 7);
        deck.put("8", 8);
        deck.put("9", 9);
        deck.put("10", 10);
        deck.put("11", 11);
        deck.put("12", 12);
        //Cartas especiales para ser implementadas en futuras versiones
        deck.put("SC", 0);
        deck.put("FT", 0);
        deck.put("FZ", 0);
        //*************************************************************
        deck.put("+2", 1);
        deck.put("+4", 1);
        deck.put("+6", 1);
        deck.put("+8", 1);
        deck.put("+10", 1);
        deck.put("X2", 1);

        total_cartas = 85; //Deben ser 94, pero eliminamos las cartas especiales
    }
    
    /**
    * Esta funcion simula el tomar una carta del deck
     * @return Regresa una String que representa el tipo de carta
    */
    @Override
    public String tomarCarta() {
        //¿Hay cartas en el mazo?
        if(total_cartas == 0){
            //Si el mazo esta vacío, llamamos nuestra funcion para restaurarlo
            this.restaurarMazo();
            //Sumamos todos los numeros de cartas de cada tipo en el mazo para
            //calcular el total de cartas nuevo
            for(Integer i:deck.values()){
                total_cartas += i;
            }
            //¿Por que no hacemos total_cartas = 85? porque las cartas que esten
            //en la mano de los jugadores no se revuelven
        }
        
        //Creamos un arrayList para saber que tipos de cartas hay disponibles
        ArrayList<String> disponibles = new ArrayList<>();
        //¿Hay 1 o mas cartas de este tipo en el deck? entonces entra al arreglo
        //de disponibles
        for(String s:deck.keySet()){
            if(deck.get(s) > 0){
                disponibles.add(s);
            }
        }
        //https://www.geeksforgeeks.org/generating-random-numbers-in-java/
        //Creamos un objeto Random
        Random r = new Random();
        //Generamos un numero aleatorio en el rango de disponibles.size()
        int i = r.nextInt(disponibles.size());
        //Obtenemos el tipo de carta usando el numero generado como indice
        String carta = disponibles.get(i);
        //Usamos una variable auxiliar para manejar la cantidad de cartas del tipo elegido
        int cartas_restantes = deck.get(carta);
        //Quitamos una carta
        cartas_restantes--;
        //Guardamos en el HashMap que quitamos una carta de ese tipo
        deck.replace(carta, cartas_restantes);
        //Restamos 1 al total de cartas
        total_cartas--;
        //Mostramos en el Label la cantidad actualizada de cartas
        restantes.setText(total_cartas + " cartas restantes");
        //Return a la carta que tomamos
        return carta;
    }
    /**
    * Esta funcion simula el revolver el mazo de descarte y crear un deck nuevo
    */
    @Override
    public void restaurarMazo() {
        //https://www.geeksforgeeks.org/hashmap-clone-method-in-java/
        //clonamos el mazo de descarte al objeto deck
        //El mazo de descarte recibe las cartas en la mano de un jugador cada vez que se retira
        deck  = (HashMap<String, Integer>) descarte.clone();
        //Reiniciamos la baraja de descarte
        descarte.clear();
        //Mostramos un texto para indicar que se esta restaurando el deck
        restantes.setText("Restaurando deck...");
        //Pausamos la ejecucion durante 1 segundo. Debido a que si el cambio es instantaneo es demasiado rapido para notarlo
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Mazo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
