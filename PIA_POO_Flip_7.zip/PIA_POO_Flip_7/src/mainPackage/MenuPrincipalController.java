package mainPackage;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Esta clase se encarga de gestionar todos los eventos y acciones en el escenario: MenuPrincipal
 */
public class MenuPrincipalController {

    //Variables utiles para cambiar de escena
    private Stage stage;
    private Scene scene;
    private Parent root;
    
    /**
    * 
    * Esta funcion nos ayuda a pasar a la escena: SeleccionarJugadores
     * @param click representa la accion de hacer click en un botón
     * @throws java.io.IOException por si intentamos cargar un archivo inexistente
    */
    public void pulsarBotonJugar(ActionEvent click) throws IOException{
        //Creamos un nodo padre con el archivo FXML de la siguiente escena
        root = FXMLLoader.load(getClass().getResource("/SeleccionarJugadores.fxml"));
        //Obtenemos el escenario en que nos encontramos actualmente
        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();
        //Creamos una nueva escena en el nodo padre
        scene = new Scene(root);
        //La escena se establece en la ventana y la mostramos
        stage.setScene(scene);
        stage.show();
    }

    /**
    * 
    * Esta funcion nos ayuda a pasar a la escena: HowToPlay
     * @param click representa la accion de hacer click en un botón
     * @throws java.io.IOException por si intentamos cargar un archivo inexistente
    */
    public void pulsarBotonHowToPlay(ActionEvent click) throws IOException{
        //Creamos un nodo padre con el archivo FXML de la siguiente escena
        root = FXMLLoader.load(getClass().getResource("/HowToPlay.fxml"));
        //Obtenemos el escenario en que nos encontramos actualmente
        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();
        //Creamos una nueva escena en el nodo padre
        scene = new Scene(root);
        //La escena se establece en la ventana y la mostramos
        stage.setScene(scene);
        stage.show();
    }
    

    //la anotacion FXML nos permite inyectar un objeto del archivo FXML en nuestro codigo
    //para poder manipularlo mediante codigo
    @FXML
    //Esta variable representa el escenario actual a nivel de objeto
    private AnchorPane ScenePane;
    
    /**
    * Esta funcion nos da un boton para salir y cerrar el programa
     * @param click representa la accion de hacer click en un botón
    */
    public void pulsarBotonSalir(ActionEvent click){
        //Creamos una alerta que se activara al hacer click en el boton Salir
        Alert alertaClose = new Alert(AlertType.CONFIRMATION);
        //Le damos un titulo a la ventana de alerta
        alertaClose.setTitle("Flip 7");
        //Establecemos el texto de la alerta
        alertaClose.setHeaderText("¿Estas seguro que deseas salir de la aplicacion?");
        
        //Si hacemos click en aceptar la alerta, la ventana será cerrada
        if(alertaClose.showAndWait().get() == ButtonType.OK){
            stage = (Stage) ScenePane.getScene().getWindow();
            stage.close();
        }   
    }
}
