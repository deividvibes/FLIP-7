package mainPackage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Esta clase se encarga de gestionar todos los eventos y acciones en el escenario: JuegoPrincipal
 */
public class JuegoPrincipalController implements Initializable{
    //Variables utiles para cambiar de escena
    private Stage stage;
    private Scene scene;
    private Parent root;
    //Instancia de JuegoLogica
    JuegoLogica run;
    //Label que muestra las acciones que se ejecutan
    @FXML
    public Label Accion;
    //Array de jugadores, solo utilizado para la puntuacion final
    static ArrayList<Jugador> jugadores;
    /**
     * Esta funcion nos ayuda a pasar a la escena: PuntuacionFinal
     * @param click representa la accion de hacer click en un botón
     * @throws java.io.IOException por si intentamos cargar un archivo inexistente
     */
    public void pulsarBotonPuntuacionFinal(ActionEvent click) throws IOException{
        //Calcula el arreglo de jugadores ordenado
        jugadores = run.puntuacionFinal();
        //Creamos un nodo padre con el archivo FXML de la siguiente escena
        root = FXMLLoader.load(getClass().getResource("/PuntuacionFinal.fxml"));
        //Obtenemos el escenario en que nos encontramos actualmente
        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();
        //Creamos una nueva escena en el nodo padre
        scene = new Scene(root);
        //La escena se establece en la ventana y la mostramos
        stage.setScene(scene);
        stage.show();
    }
    
    //Todos los labels usados en la pantalla
    @FXML
    private Label puntos1;
    @FXML
    private Label puntos2;
    @FXML
    private Label puntos3;
    @FXML
    private Label puntos4;
    @FXML
    private Label puntos5;
    @FXML
    private Label puntos6;
    
    @FXML
    private Label manoAlias1;
    @FXML
    private Label manoAlias2;
    @FXML
    private Label manoAlias3;
    @FXML
    private Label manoAlias4;
    @FXML
    private Label manoAlias5;
    @FXML
    private Label manoAlias6;
    @FXML
    private Label LabelTurno;
    //Rectangulos usados para marcar que un jugador se retiro
    @FXML
    private Rectangle retiradoCuadro1;
    @FXML
    private Rectangle retiradoCuadro2;
    @FXML
    private Rectangle retiradoCuadro3;
    @FXML
    private Rectangle retiradoCuadro4;
    @FXML
    private Rectangle retiradoCuadro5;
    @FXML
    private Rectangle retiradoCuadro6;

    
    @FXML
    private Label restantes;
    
    /** Esta funcion se ejecuta de manera similar a un main, al cargar la escena comienza su ejecución
    * 
     * @param url tiene la ubicacion del nodo padre, para poder hacer busquedas relativas de ser necesario
     * @param rb tiene los recursos utilizados para localizar al nodo padre.
    */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Llamamos a una funcion aparte por limpieza, ya que esa funcion requiere de 66 objetos, 11 espacios de mano por 6 jugadores
        ArrayList<ArrayList<ImageView>> manos = this.setupManos();
        //Instanciamos el objeto JuegoLogica
        run = new JuegoLogica();
        //pasamos a JuegoLogica el objeto Label restantes
        run.mazo.restantes = restantes;
        //Nos traemos ListDatos de SeleccionarJugadores
        ArrayList<DatosJugador> ListDatos = SeleccionarJugadoresController.getListDatos();
        //Hacemos un array de los alias que se mostraran en pantalla
        ArrayList<Label> manoAlias = new ArrayList<>();
        manoAlias.add(manoAlias1);
        manoAlias.add(manoAlias2);
        manoAlias.add(manoAlias3);
        manoAlias.add(manoAlias4);
        manoAlias.add(manoAlias5);
        manoAlias.add(manoAlias6);
        //Hacemos un array de los labels de puntos y de los rectangulos
        ArrayList<Label> puntos = new ArrayList<>(Arrays.asList(puntos1,puntos2,puntos3,puntos4,puntos5,puntos6));
        ArrayList<Rectangle> rec = new ArrayList<>(Arrays.asList(retiradoCuadro1,retiradoCuadro2,retiradoCuadro3,retiradoCuadro4,retiradoCuadro5,retiradoCuadro6));
        //PlaceHolder para el jugador
        Jugador PlayerPH;
        for(DatosJugador p:ListDatos){
            //Para todos los jugadores con alias(jugadores activos)
            if(!p.getLabel().getText().isEmpty()){
                //Copiamos su alias al que se mostrara en pantalla junto a sus cartas
                manoAlias.get(ListDatos.indexOf(p)).setText("MANO DE " + p.getLabel().getText().toUpperCase());
                manoAlias.get(ListDatos.indexOf(p)).setTextFill(p.getLabel().getTextFill());
                //Mostramos sus puntos en el color elegido
                puntos.get(ListDatos.indexOf(p)).setText("PUNTOS: ");
                puntos.get(ListDatos.indexOf(p)).setTextFill(p.getLabel().getTextFill());
                //Creamos un Jugador
                PlayerPH = new Jugador(p.getLabel().getText());
                //Le asignamos un conjunto de cartas, un label de puntos, un rectangulo de retirado y el letrero de accion global
                PlayerPH.mano_image = manos.get(ListDatos.indexOf(p));
                PlayerPH.puntosL = puntos.get(ListDatos.indexOf(p));
                PlayerPH.retiradoCuadro = rec.get(ListDatos.indexOf(p));
                PlayerPH.Accion = Accion;
                //Lo agregamos a run
                run.agregarJugador(PlayerPH);
            }
        }
        //Empezamos la partida por el primer jugador
        jugadorEnTurno = run.jugadores.get(0);
        //Mostramos en pantalla de quien es el turno
        LabelTurno.setText(jugadorEnTurno.alias);
    }
    //Variable que muestra al jugador en turno
    static Jugador jugadorEnTurno; 
    /**
     * Se encarga de mostrar en pantalla las cartas del jugador
     * @param click representa la accion de hacer click en un botón
     */
    public void tomarCarta(ActionEvent click){
        //el jugador en turno toma una carta
        String cartaS = run.hitJugador(jugadorEnTurno);
        //La carta obtenida la pasamos a imagen
        Image carta = new Image(cartaS +".png");
        //Si el jugador no perdio con esa carta:
        if(!jugadorEnTurno.retirado){
            //Se asigna en su proximo espacio libre en mano
            if(!jugadorEnTurno.mano.isEmpty()){
               jugadorEnTurno.mano_image.get(jugadorEnTurno.mano.size()-1).setImage(carta);
            }
            else{
                jugadorEnTurno.mano_image.get(jugadorEnTurno.mano.size()).setImage(carta);
            }   
        }
        //Si el jugador perdio con esa carta:
        else{
            //Se pone la carta en el ultimo espacio
            jugadorEnTurno.mano_image.get(10).setImage(carta);
        }
        //Se muestra en el label los puntos del jugador, tomando en cuenta si tiene o no un *2
        if(jugadorEnTurno.mano.contains("X2")){
            jugadorEnTurno.puntosL.setText(jugadorEnTurno.alias.toUpperCase() + ": " + jugadorEnTurno.puntuacion + " + " +jugadorEnTurno.puntos_mano*2 + "(" + jugadorEnTurno.modificadores + ")");
        }
        else{
            jugadorEnTurno.puntosL.setText(jugadorEnTurno.alias.toUpperCase() + ": " + jugadorEnTurno.puntuacion + " + " +jugadorEnTurno.puntos_mano + "(" + jugadorEnTurno.modificadores + ")");
        }
        //Si el jugador llegó a flip 7, se acaba la ronda
        if(jugadorEnTurno.flip >= 7){
            this.reiniciarRonda();
        }
        //De lo contrario, solo pasa el turno
        else{
            this.pasarTurno();
        }
    }
    //Nos ayuda a no buscar jugadores activos infinitamente
    HashSet<Jugador> jugadorVisitado = new HashSet<>();
    /**
     * Se encarga de buscar al siguiente jugador en turno
     */
    public void pasarTurno(){
        //Obtenemos el index del jugador siguiente
        int t = run.jugadores.indexOf(jugadorEnTurno) + 1;
        //Nos aseguramos de dar la vuelta si es necesario
        t = t%run.jugadores.size();
        //Mientras no hayamos visitado todos los jugadores
        while(jugadorVisitado.size() < run.jugadores.size()){
            //el jugador en el que estamos ya se retiro?
            if(run.jugadores.get(t).retirado){
                //Lo añadimos a jugadorVisitado, pasamos al siguiente
                jugadorVisitado.add(run.jugadores.get(t));
                t++;
                t = t%run.jugadores.size();
            }
            else{
                //Al llegar a un jugador activo, le pasamos el turno y lo mostramos en el Label
                jugadorEnTurno = run.jugadores.get(t);
                LabelTurno.setText(jugadorEnTurno.alias);
                //Reiniciamos el set
                jugadorVisitado.clear();
                return;
            }
        }
        //Si ningun jugador esta activo, reiniciamos la ronda
        this.reiniciarRonda();
        //Reiniciamos el set
        jugadorVisitado.clear();
    }
    /**
     * Se encarga de reiniciar la ronda cuando no quedan jugadores activos
     */
    public void reiniciarRonda(){
        //Definimos que no es el final del juego
        boolean finalJuego = false;
        
        //Detenemos el sistema un momento para notar que es el final de una ronda
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(JuegoPrincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }
        //Si alguno de los jugadores supera o iguala 200 puntos, es el final del juego
        for(Jugador j:run.jugadores){
            if(j.puntuacion >= 200){
                finalJuego = true;
            }
        }
        //Final del juego muestra un cartel y no resetea la ronda, por lo que la unica opcion es clickear en puntuacion final
        if(finalJuego){
            Accion.setText("FINAL DEL JUEGO, Haga click en puntuacion final");
        }
        //Reiniciamos la ronda
        else{
            //Todos los jugadores dejan de estar retirados y dejan de mostrar el rectangulo
            for(Jugador j:run.jugadores){
                j.retirado = false;

                j.retiradoCuadro.setOpacity(0);

                //todas las cartas desaparecen
                for(ImageView i:j.mano_image){
                    i.setImage(null);
                }
            }
        }
    }
    /**
     * El boton de retirarse, para que el jugador pueda decidir cuando dejar de sacar cartas
     * @param click representa la accion de hacer click en un botón
     */
    public void botonRetirarse(ActionEvent click){
        //Llamamos a la funcion en Jugador
        jugadorEnTurno.retirarse();
        //Mostramos sus puntos actualizados, tomando en cuenta si tiene o no X2
        if(jugadorEnTurno.mano.contains("X2")){
            jugadorEnTurno.puntosL.setText("PUNTOS: " + jugadorEnTurno.puntuacion + " + " +jugadorEnTurno.puntos_mano*2 + "(" + jugadorEnTurno.modificadores + ")");
        }
        else{
            jugadorEnTurno.puntosL.setText( "PUNTOS: " + jugadorEnTurno.puntuacion + " + " +jugadorEnTurno.puntos_mano + "(" + jugadorEnTurno.modificadores + ")");
        }
        //Pasamos el turno al siguiente jugador
        this.pasarTurno();
    }
    //Los objetos necesarios para mostrar las imagenes en pantalla
    @FXML
    private ImageView Hand11;
    @FXML
    private ImageView Hand12;
    @FXML
    private ImageView Hand13;
    @FXML
    private ImageView Hand14;
    @FXML
    private ImageView Hand15;
    @FXML
    private ImageView Hand16;
    @FXML
    private ImageView Hand17;
    @FXML
    private ImageView Hand18;
    @FXML
    private ImageView Hand19; 
    @FXML
    private ImageView Hand110;
    @FXML
    private ImageView Hand111;
    
    @FXML
    private ImageView Hand21;
    @FXML
    private ImageView Hand22;
    @FXML
    private ImageView Hand23;
    @FXML
    private ImageView Hand24;
    @FXML
    private ImageView Hand25;
    @FXML
    private ImageView Hand26;
    @FXML
    private ImageView Hand27;
    @FXML
    private ImageView Hand28;
    @FXML
    private ImageView Hand29; 
    @FXML
    private ImageView Hand210;
    @FXML
    private ImageView Hand211;
    
    @FXML
    private ImageView Hand31;
    @FXML
    private ImageView Hand32;
    @FXML
    private ImageView Hand33;
    @FXML
    private ImageView Hand34;
    @FXML
    private ImageView Hand35;
    @FXML
    private ImageView Hand36;
    @FXML
    private ImageView Hand37;
    @FXML
    private ImageView Hand38;
    @FXML
    private ImageView Hand39; 
    @FXML
    private ImageView Hand310;
    @FXML
    private ImageView Hand311;

    @FXML
    private ImageView Hand41;
    @FXML
    private ImageView Hand42;
    @FXML
    private ImageView Hand43;
    @FXML
    private ImageView Hand44;
    @FXML
    private ImageView Hand45;
    @FXML
    private ImageView Hand46;
    @FXML
    private ImageView Hand47;
    @FXML
    private ImageView Hand48;
    @FXML
    private ImageView Hand49; 
    @FXML
    private ImageView Hand410;
    @FXML
    private ImageView Hand411;
    
    @FXML
    private ImageView Hand51;
    @FXML
    private ImageView Hand52;
    @FXML
    private ImageView Hand53;
    @FXML
    private ImageView Hand54;
    @FXML
    private ImageView Hand55;
    @FXML
    private ImageView Hand56;
    @FXML
    private ImageView Hand57;
    @FXML
    private ImageView Hand58;
    @FXML
    private ImageView Hand59; 
    @FXML
    private ImageView Hand510;
    @FXML
    private ImageView Hand511;
    
    @FXML
    private ImageView Hand61;
    @FXML
    private ImageView Hand62;
    @FXML
    private ImageView Hand63;
    @FXML
    private ImageView Hand64;
    @FXML
    private ImageView Hand65;
    @FXML
    private ImageView Hand66;
    @FXML
    private ImageView Hand67;
    @FXML
    private ImageView Hand68;
    @FXML
    private ImageView Hand69; 
    @FXML
    private ImageView Hand610;
    @FXML
    private ImageView Hand611;
    
    
    //https://www.geeksforgeeks.org/initialize-an-arraylist-in-java/
    /**
     * Acomoda en arrays los ImageView
     * @return el array de arrays que forma
     */
    private ArrayList<ArrayList<ImageView>> setupManos() {
        //Crea un array por cada mano
        ArrayList<ImageView> mano1 = new ArrayList<>(Arrays.asList(Hand11,Hand12,Hand13,Hand14,Hand15,Hand16,Hand17,Hand18,Hand19,Hand110,Hand111));
        ArrayList<ImageView> mano2 = new ArrayList<>(Arrays.asList(Hand21,Hand22,Hand23,Hand24,Hand25,Hand26,Hand27,Hand28,Hand29,Hand210,Hand211));
        ArrayList<ImageView> mano3 = new ArrayList<>(Arrays.asList(Hand31,Hand32,Hand33,Hand34,Hand35,Hand36,Hand37,Hand38,Hand39,Hand310,Hand311));
        ArrayList<ImageView> mano4 = new ArrayList<>(Arrays.asList(Hand41,Hand42,Hand43,Hand44,Hand45,Hand46,Hand47,Hand48,Hand49,Hand410,Hand411));
        ArrayList<ImageView> mano5 = new ArrayList<>(Arrays.asList(Hand51,Hand52,Hand53,Hand54,Hand55,Hand56,Hand57,Hand58,Hand59,Hand510,Hand511));
        ArrayList<ImageView> mano6 = new ArrayList<>(Arrays.asList(Hand61,Hand62,Hand63,Hand64,Hand65,Hand66,Hand67,Hand68,Hand69,Hand610,Hand611));
        //Junta todos los arrays en un array y lo devuelve
        ArrayList<ArrayList<ImageView>> manos = new ArrayList<>(Arrays.asList(mano1,mano2,mano3,mano4,mano5,mano6));
        return manos;
    }

    
}
