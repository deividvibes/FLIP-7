package mainPackage;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Esta clase se encarga de gestionar todos los eventos y acciones en el escenario: PuntuacionFinal
 */
public class PuntuacionFinalController implements Initializable{
    //Variable para poder cerrar el escenario(ventana)
    private Stage stage;
    
    //la anotacion FXML nos permite inyectar un objeto del archivo FXML en nuestro codigo
    //para poder manipularlo mediante codigo
    @FXML
    //Esta variable representa el escenario actual a nivel de objeto
    private AnchorPane ScenePane;
    
    /**
    * Esta funcion nos da un boton para salir y cerrar el programa
     * @param click representa la accion de hacer click en un botón
    */
    public void pulsarBotonRegresar(ActionEvent click){
        //Creamos una alerta que se activara al hacer click en el boton Salir
        Alert alertaClose = new Alert(Alert.AlertType.CONFIRMATION);
        //Le damos un titulo a la ventana de alerta
        alertaClose.setTitle("Flip 7");
        //Establecemos el texto de la alerta
        alertaClose.setHeaderText("GRACIAS POR JUGAR");
        //Si hacemos click en aceptar la alerta, la ventana será cerrada
        if(alertaClose.showAndWait().get() == ButtonType.OK){
            stage = (Stage) ScenePane.getScene().getWindow();
            stage.close();
        }
    }

    //Hacemos inyeccion de los objetos label
    //Estos muestran en texto cada posicion en el marcador
    @FXML
    private Label puntuacion1;
    @FXML
    private Label puntuacion2;
    @FXML
    private Label puntuacion3;
    @FXML
    private Label puntuacion4;
    @FXML
    private Label puntuacion5;
    @FXML
    private Label puntuacion6;
    
    /** Esta funcion se ejecuta de manera similar a un main, al cargar la escena comienza su ejecución
    * 
     * @param url tiene la ubicacion del nodo padre, para poder hacer busquedas relativas de ser necesario
     * @param rb tiene los recursos utilizados para localizar al nodo padre.
    */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Obtenemos el arreglo con los jugadores activos desde JuegoPrincipalController. Este arreglo llega ya ordenado
        ArrayList<Jugador> jugadores = JuegoPrincipalController.jugadores;
        //Creamos un arreglo para las 6 Label que indican al usuario en que posicion quedaron
        ArrayList<Label> posicion = new ArrayList<>();
        posicion.add(puntuacion1);
        posicion.add(puntuacion2);
        posicion.add(puntuacion3);
        posicion.add(puntuacion4);
        posicion.add(puntuacion5);
        posicion.add(puntuacion6);
        
        //Para cada jugador activo, lo mostramos en su lugar correspondiente
        //Vamos de mayor a menor y en cuanto se acaben los jugadores activos las Label
        //restantes se quedan con un texto por defecto
        for(int i = 0; i < jugadores.size(); i++){
            //i+1 es en que lugar quedo, y el alias es el nombre del jugador
            posicion.get(i).setText(i+1 + ". " + jugadores.get(i).alias);

        }
    }
    
}
