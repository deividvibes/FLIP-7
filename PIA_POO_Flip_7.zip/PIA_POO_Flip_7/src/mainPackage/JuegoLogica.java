package mainPackage;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * Esta clase se encarga de manejar la interaccion mazo-jugador y otros aspectos de la partida
 * como el numero de jugadores y calcular la puntuacion final
 */
public class JuegoLogica {
    //Iniciamos un objeto Mazo
    Mazo mazo = new Mazo();
    //Arreglo de los jugadores en la partida
    ArrayList<Jugador> jugadores = new ArrayList<>();
    
    
    /**Simula dar una carta a un jugador
    * 
     * @param j Jugador que recibe la carta
     * @return carta obtenida
    */
    public String hitJugador(Jugador j){
        //https://www.w3schools.com/java/java_switch.asp
        //Tomamos una carta del mazo
        String carta = mazo.tomarCarta();
        //Si es X2 aplicamos el caso correspondiente, si no, aplicamos el default
        //Utilizamos switch para poder implementar nuevas cartas en versiones siguientes
        switch(carta){
                case "X2":
                    j.X2();
                    break;
                default:
                    j.recibirCarta(carta);
        }
        return carta;
    }
    
    /**Agregamos jugadores al arreglo
     *
     * @param j Jugador que será añadido a la partida
     */
    public void agregarJugador(Jugador j){
        jugadores.add(j);
    }
    


    /**Agregamos jugadores al arreglo
     *
     * @return El ArrayList ordenado
     */
    public ArrayList<Jugador> puntuacionFinal(){
        //Definimos un criterio de comparacion
        Comparator JC = new JugadorComparator();
        //Ordenamos la lista y la retornamos
        jugadores.sort(JC);
        return jugadores;
    }
}
