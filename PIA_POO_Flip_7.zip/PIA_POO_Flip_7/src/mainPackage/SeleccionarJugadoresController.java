package mainPackage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Esta clase se encarga de gestionar todos los eventos y acciones en el escenario: SeleccionarJugadores
 */
public class SeleccionarJugadoresController implements Initializable{
    //Variables utiles para cambiar de escena
    private Stage stage;
    private Scene scene;
    private Parent root;
    /**
    * Esta funcion nos ayuda a pasar a la escena: JuegoPrincipal
     * @param click representa la accion de hacer click en un botón
     * @throws java.io.IOException por si intentamos cargar un archivo inexistente
    */   
    public void pulsarBotonAJugar(ActionEvent click) throws IOException{
        //Creamos un nodo padre con el archivo FXML de la siguiente escena
        root = FXMLLoader.load(getClass().getResource("/JuegoPrincipal.fxml"));
        //Obtenemos el escenario en que nos encontramos actualmente
        stage = (Stage) ((Node)click.getSource()).getScene().getWindow();
        //Creamos una nueva escena en el nodo padre
        scene = new Scene(root);
        //La escena se establece en la ventana y la mostramos
        stage.setScene(scene);
        stage.show();
    }
    //Todas las inyecciones necesarias de los objetos en DatosJugador para los 6 jugadores
    @FXML
    private AnchorPane PlayerData1;
    @FXML
    private AnchorPane PlayerData2;
    @FXML
    private AnchorPane PlayerData3;
    @FXML
    private AnchorPane PlayerData4;
    @FXML
    private AnchorPane PlayerData5;
    @FXML
    private AnchorPane PlayerData6;

    @FXML
    private ChoiceBox<String> PlayerStatus1;
    @FXML
    private ChoiceBox<String> PlayerStatus2;
    @FXML
    private ChoiceBox<String> PlayerStatus3;
    @FXML
    private ChoiceBox<String> PlayerStatus4;
    @FXML
    private ChoiceBox<String> PlayerStatus5;
    @FXML
    private ChoiceBox<String> PlayerStatus6;
    //Opciones disponibles en el ChoiceBox
    private final String[] status = {"Desactivado", "Jugador"};
    
    @FXML
    private ToggleButton Listo1;
    @FXML
    private ToggleButton Listo2;
    @FXML
    private ToggleButton Listo3;
    @FXML
    private ToggleButton Listo4;
    @FXML
    private ToggleButton Listo5;
    @FXML
    private ToggleButton Listo6;
    
    @FXML
    private TextField alias1;
    @FXML
    private TextField alias2;
    @FXML
    private TextField alias3;
    @FXML
    private TextField alias4;
    @FXML
    private TextField alias5;
    @FXML
    private TextField alias6;
    
    @FXML
    private ColorPicker color1;
    @FXML
    private ColorPicker color2;
    @FXML
    private ColorPicker color3;
    @FXML
    private ColorPicker color4;
    @FXML
    private ColorPicker color5;
    @FXML
    private ColorPicker color6;
    
    @FXML
    private Label label1;
    @FXML
    private Label label2;
    @FXML
    private Label label3;
    @FXML
    private Label label4;
    @FXML
    private Label label5;
    @FXML
    private Label label6;
    
    //Un array de DatosJugador para manejar las 6 entidades en pantalla
    private static final ArrayList<DatosJugador> ListDatos = new ArrayList<>();
    //GETTER ListDatos
    public static ArrayList<DatosJugador> getListDatos() {
        return ListDatos;
    }
    /** Esta funcion se ejecuta de manera similar a un main, al cargar la escena comienza su ejecución
    * 
     * @param url tiene la ubicacion del nodo padre, para poder hacer busquedas relativas de ser necesario
     * @param rb tiene los recursos utilizados para localizar al nodo padre.
    */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //añadimos a ListDatos los 6 registros
        getListDatos().add(0, new DatosJugador(PlayerData1, PlayerStatus1, Listo1, alias1, color1, label1));
        getListDatos().add(1, new DatosJugador(PlayerData2, PlayerStatus2, Listo2, alias2, color2, label2));
        getListDatos().add(2, new DatosJugador(PlayerData3, PlayerStatus3, Listo3, alias3, color3, label3));
        getListDatos().add(3, new DatosJugador(PlayerData4, PlayerStatus4, Listo4, alias4, color4, label4));
        getListDatos().add(4, new DatosJugador(PlayerData5, PlayerStatus5, Listo5, alias5, color5, label5));
        getListDatos().add(5, new DatosJugador(PlayerData6, PlayerStatus6, Listo6, alias6, color6, label6));
        
        //Añadimos las opciones del ChoiceBox a cada registro
        for(DatosJugador p:getListDatos()){
            p.getpStatus().getItems().addAll(status);
        }
        
        //Establecemos un evento que se activa al seleccionar una opcion en cualquiera de los ChoiceBox
        for(DatosJugador p:getListDatos()){
            p.getpStatus().setOnAction(this::iniciarJugadores);
        } 
    }
    
    //el boton para pasar a la pantalla de jugar
    @FXML
    private Button BotonAJugar;
    boolean todosListos;
    //https://openjfx.io/javadoc/11/javafx.graphics/javafx/scene/Node.html#isDisable()
    /**
     * 
     * @param event Se activa cada que se modifica un ChoiceBox
     */
    public void iniciarJugadores(ActionEvent event){
        //Para cada registro...
        for(DatosJugador p:getListDatos()){
            //Si se eligio: Desactivado...
            if(p.getpStatus().getValue().equals("Desactivado")){
                //Eliminar el texto en el campo de texto
                p.getAlias().clear();
                //Desabilitar el panel completo
                p.getPanel().setDisable(true);
                //Seleccionar listo, esto para que los jugadores desactivados no afecten la logica del boton "A Jugar!"
                p.getListo().setSelected(true);
            }
            //Si no se eligio "Desactivado"...
            else{
                //Activar el panel
                p.getPanel().setDisable(false);
                //Si el campo de texto esta vacio no se puede dar click a listo, para evitar que dejen ese campo vacio
                if(p.getAlias().getCharacters().isEmpty()){
                    p.getListo().setSelected(false);
                }
            }
        }
        //Establecemos una variable para saber si todos los jugadores estan listos
        todosListos = true;
        for(DatosJugador p:getListDatos()){
            //Si al menos uno de los jugadores no esta listo, todosListos es Falso
            if(!p.getListo().isSelected()){
                todosListos = false;
            }
            else{
                //Se asegura que al activar un jugador el campo de listo se desactive
                if(p.getAlias().getCharacters().isEmpty() && !p.getPanel().isDisabled() && p.getListo().isSelected()){
                    p.getListo().setSelected(false);
                    todosListos = false;
                }
            }
        }
        //el boton de Jugar solo esta disponible cuando todos los jugadores estan listos
        if(todosListos){
            BotonAJugar.setDisable(false);
        }
        else{
            BotonAJugar.setDisable(true);
        }
    }
    /**
     * 
     * @param click representa la accion de hacer click en un botón
     */
    public void botonListo(ActionEvent click){
        //Establecemos una variable para saber si todos los jugadores estan listos
        todosListos = true;
        for(DatosJugador p:getListDatos()){
            //Si al menos uno de los jugadores no esta listo, todosListos es Falso
            if(!p.getListo().isSelected()){
                todosListos = false;
            }
            else{
                //Se asegura que al activar un jugador el campo de listo se desactive
                if(p.getAlias().getCharacters().isEmpty() && !p.getPanel().isDisabled() && p.getListo().isSelected()){
                    p.getListo().setSelected(false);
                    todosListos = false;
                }
            }
        }
        //el boton de Jugar solo esta disponible cuando todos los jugadores estan listos
        if(todosListos){
            BotonAJugar.setDisable(false);
        }
        else{
            BotonAJugar.setDisable(true);
        }
        
        //Mostramos la etiqueta de jugador con su nombre y su color
        for(DatosJugador p:getListDatos()){
            //Para los jugadores listos...
            if(p.getListo().isSelected()){
                //Se muestra la etiqueta con color y el nombre elegido
                p.getLabel().setText(p.getAlias().getCharacters().toString().toUpperCase());
                p.getLabel().setTextFill(p.getColor().getValue());
                //Si no esta desactivado el jugado (Es un jugador activo y Listo) se desactivan las opciones de color y texto,
                //Si estas listo, no puedes cambiar estas opciones
                if(!p.getPanel().isDisabled()){
                   p.getColor().setDisable(true);
                   p.getAlias().setDisable(true); 
                }
                
            }
            //Para aquellos no listos se desactiva la etiqueta y se activan los campos de color y de texto
            else{
                p.getLabel().setText("");
                p.getColor().setDisable(false);
                p.getAlias().setDisable(false);
            }
        }
    }
}
