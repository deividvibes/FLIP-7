package mainPackage;

import java.util.Comparator;
//https://www.w3schools.com/java/java_advanced_sorting.asp
/**Clase que define el criterio de comparacion entre los jugadores
 */
public class JugadorComparator implements Comparator{

    /**Clase que define el criterio de comparacion entre los jugadores
     * @param a Objeto 1 a comparar
     * @param b Objeto 2 a comparar
     * @return  un numero que indica cual de los dos objetos tiene prioridad en el ordenamiento
    */
    @Override
    public int compare(Object a, Object b) {
        //Definimos a los objetos como Jugadores
        Jugador j1 = (Jugador) a;
        Jugador j2 = (Jugador) b;
        //Al comparar dos jugadores, nos interesa acomodarlos por su puntuacion, de la siguiente manera
        if(j1.puntuacion < j2.puntuacion) return 1;
        if(j1.puntuacion > j2.puntuacion) return -1;
        return 0;
        
    }
    
}
